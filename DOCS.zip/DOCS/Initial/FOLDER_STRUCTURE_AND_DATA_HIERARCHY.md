# ENGINE FOLDER STRUCTURE & DATA HIERARCHY SPECIFICATION — INITIAL PHASE

## Project Name: Visual Motion & Frontend Design Studio
**Internal Codename:** "Unreal Engine for Animation & Frontend Design"  
**Document Version:** 1.0.0  
**Phase:** Initial Phase (Design, Motion & Code Emitter)  
**Status:** Production-Ready Architectural Specification  
**File Location:** `DOCS/Initial/FOLDER_STRUCTURE_AND_DATA_HIERARCHY.md`  

---

## 1. Overview & Architectural Philosophy

The Visual Motion & Frontend Design Studio separates its data and codebase architecture into two clearly defined hierarchies:
1. **HIERARCHY A: THE ENGINE CODEBASE STRUCTURE (`WebAPPBuilder/`):** The internal Next.js application housing the C++ WebAssembly spline kernel, motion runtime, dockable UI panels, and code emitters.
2. **HIERARCHY B: THE USER PROJECT & ASSET DATA HIERARCHY:** The portable declarative project format (`project.json` / `.motionproj`) representing elements, component trees, animation tracks, and export manifests.

All database models, SQL/Prisma schemas, API endpoints, Auth RBAC, and cloud deployment directories from the full-stack architecture have been eliminated from this phase.

---

## 2. Hierarchy A: The Engine Codebase Structure

```text
WebAPPBuilder/
│
├── DOCS/                                   # Architectural Specifications
│   ├── Initial/                            # INITIAL PHASE: Motion & Frontend Studio
│   │   ├── PRD.md                          # Product Requirements Document
│   │   ├── UI.md                           # UI & Workspace Architecture
│   │   ├── PANELS.md                       # Complete Panel & Tab Registry
│   │   ├── ROADMAP.md                      # Phased Implementation Milestones
│   │   ├── FOLDER_STRUCTURE_AND_DATA_HIERARCHY.md # This Document
│   │   ├── SCHEMA_REFERENCE.md             # JSON Schema Contracts
│   │   ├── CONVENTIONS.md                  # Coding & File Conventions
│   │   └── CHANGELOG.md                    # Changelog
│   └── After/                              # AFTER PHASE: Full-Stack Web App Engine
│
├── wasm/                                   # C++ HIGH-PERFORMANCE WEBASSEMBLY KERNEL
│   ├── CMakeLists.txt                      # Emscripten build manifest
│   ├── include/
│   │   ├── SplineSolver.h                  # Hermite & Cubic Bezier curve math
│   │   ├── SpringPhysics.h                 # Verlet spring & cable tension solver
│   │   └── ArcLengthParameterizer.h        # 120 FPS curve sampling
│   └── src/
│       ├── SplineSolver.cpp                # Curve geometry & tangent computation
│       ├── SpringPhysics.cpp               # Physical spring bounce simulation
│       └── WasmBindings.cpp                # EMSCRIPTEN_BINDINGS exports
│
├── public/                                 # Static Assets & Icons
│   ├── wasm/                               # Compiled Wasm binaries (.wasm + .js)
│   └── icons/                              # Lucide & engine vector icons
│
└── src/                                    # CORE APPLICATION ENGINE
    │
    ├── core/                               # FOUNDATIONAL TYPES & LOGIC
    │   ├── motion/                         # Motion subsystem
    │   │   ├── types/                      # Declarative track & keyframe schemas
    │   │   │   ├── tracks.ts               # Property tracks (transform, opacity, color, etc.)
    │   │   │   ├── keyframes.ts            # Keyframe definitions & diamond handles
    │   │   │   ├── easings.ts              # Bezier curves & spring parameter contracts
    │   │   │   └── triggers.ts             # Hover, click, scroll, mount triggers
    │   │   └── engine/                     # Motion compatibility & validation
    │   │       ├── MotionEvaluator.ts      # Checks archetype track compatibility
    │   │       ├── CurveMath.ts            # Fallback JS bezier solver
    │   │       └── Diagnostics.ts          # [ANIM_COMPAT] diagnostic dispatcher
    │   │
    │   ├── elements/                       # UI Element Archetype System
    │   │   ├── types.ts                    # Element AST node definitions
    │   │   ├── archetypes.ts               # Button, Card, Text, SVG, Container schemas
    │   │   └── defaults.ts                 # Default property values per archetype
    │   │
    │   ├── store/                          # Reactive Zustand Stores
    │   │   ├── useProjectStore.ts          # Root project AST state & undo/redo
    │   │   ├── useTimelineStore.ts         # Active playhead, zoom, tracks, selection
    │   │   ├── useSelectionStore.ts        # Active selected element & keyframe IDs
    │   │   └── useExportStore.ts           # Target framework & styling preferences
    │   │
    │   └── wasm/                           # Wasm Worker Bridge
    │       ├── WasmWorker.ts               # Web Worker wrapper for Wasm math
    │       └── WasmWorkerPool.ts           # Multi-threaded curve computation pool
    │
    ├── editor/                             # DOCKABLE STUDIO SHELL & PANELS
    │   ├── shell/                          # Layout and docking infrastructure
    │   │   ├── EditorShell.tsx             # Master viewport, docks & splitters
    │   │   ├── StudioHeader.tsx            # Top bar (Project name, Play, Export CTA)
    │   │   ├── DockSplitter.tsx            # 1D resizable splitter bars
    │   │   ├── DockCornerSplitter.tsx      # 2D simultaneous width/height drag handles
    │   │   └── FloatingDock.tsx            # Bottom floating pill toolbar
    │   │
    │   ├── panels/                         # Individual Dockable Panels
    │   │   ├── launcher/                   # Panel 00: Project Hub / Home Screen
    │   │   │   ├── ProjectHub.tsx          # Left: Scope Cards, Right: Tech Dropdowns
    │   │   │   ├── ScopeCard.tsx           # Element, Component, Page card items
    │   │   │   └── TechConfigurator.tsx    # Framework, CSS, and Animation pickers
    │   │   │
    │   │   ├── viewport/                   # Panel 01: Application Viewport
    │   │   │   ├── CanvasViewport.tsx      # Confluence dot-grid stage
    │   │   │   ├── ResponsiveStage.tsx     # Device frame wrapping & zoom controls
    │   │   │   └── ScrollSimulator.tsx     # ScrollTrigger virtual scrub overlay
    │   │   │
    │   │   ├── outliner/                   # Panel 02: Element & Animation Outliner
    │   │   │   ├── ElementOutliner.tsx     # Tree view: Element ➔ Child ➔ Animation
    │   │   │   ├── TreeNode.tsx            # Node row with mute/solo/lock toggles
    │   │   │   └── QuickAddModal.tsx       # Popover to attach new animations
    │   │   │
    │   │   ├── details/                    # Panel 03: Details & Properties Inspector
    │   │   │   ├── DetailsInspector.tsx    # Master accordion inspector
    │   │   │   ├── TransformSection.tsx    # X, Y, Z, Rotation, Scale, Origin
    │   │   │   ├── LayoutSection.tsx       # Flexbox, CSS Grid, Gap, Padding
    │   │   │   ├── AppearanceSection.tsx   # Colors, Gradients, Radius, Shadows
    │   │   │   ├── TypographySection.tsx   # Fonts, Weights, Sizes, Line heights
    │   │   │   └── SvgSection.tsx          # Fill, Stroke, Dashoffset, Path editor
    │   │   │
    │   │   ├── content/                    # Panel 04: Content & Motion Browser
    │   │   │   ├── ContentBrowser.tsx      # Asset drawer with live hover previews
    │   │   │   └── AssetCard.tsx           # Draggable cards for presets & curves
    │   │   │
    │   │   ├── sequencer/                  # Panel 05: Motion Sequencer
    │   │   │   ├── MotionSequencer.tsx     # Multi-track keyframe timeline
    │   │   │   ├── TrackHeader.tsx         # Track label, color badge, mute/solo
    │   │   │   ├── KeyframeTrack.tsx       # Horizontal track with diamond markers
    │   │   │   └── PlayheadControls.tsx    # Play, Pause, Loop, Reverse, Scrub bar
    │   │   │
    │   │   ├── curves/                     # Panel 06: Curve Editor
    │   │   │   ├── CurveEditor.tsx         # Visual cubic bezier handle editor
    │   │   │   └── SpringEditor.tsx        # Framer Motion spring physics visualizer
    │   │   │
    │   │   ├── code/                       # Panel 07: Live Code Inspector
    │   │   │   ├── CodeInspector.tsx       # Split-tab syntax-highlighted viewer
    │   │   │   └── ExportDialog.tsx        # Copy code & Download ZIP package
    │   │   │
    │   │   ├── output/                     # Panel 08: Output Log & Diagnostics
    │   │   │   └── OutputLog.tsx           # Filterable diagnostic event stream
    │   │   │
    │   │   ├── sandbox/                    # Panel 09: Play & Interaction Sandbox
    │   │   │   └── InteractionSandbox.tsx  # Zero-build interactive testing stage
    │   │   │
    │   │   └── ai/                         # Panel 11: MotionAI Assistant
    │   │       ├── MotionAICoPilot.tsx     # Conversational prompt assistant
    │   │       └── DiffPreview.tsx         # Translucent ghost keyframe diff
    │   │
    │   └── styles/                         # Scoped Panel Stylesheets
    │       ├── tokens.css                  # Global design tokens & CSS variables
    │       ├── globals.css                 # CSS reset & custom scrollbars
    │       ├── animations.css              # Micro-interaction keyframes
    │       ├── launcher.css                # Scoped styles for Screen 00 Hub
    │       ├── viewport.css                # Scoped canvas styles
    │       ├── outliner.css                # Scoped outliner tree styles
    │       ├── details.css                 # Scoped inspector styles
    │       ├── sequencer.css               # Scoped timeline styles
    │       └── code.css                    # Scoped code viewer styles
    │
    ├── compiler/                           # CLEAN CODE EMITTER PIPELINE
    │   ├── ast/                            # AST Transformers & Normalizers
    │   ├── emitters/                       # Framework & library code generators
    │   │   ├── react/                      # React 19 / Next.js 15 TSX Emitter
    │   │   ├── tailwind/                   # Tailwind CSS class synthesizer
    │   │   ├── css/                        # Scoped CSS modules & keyframe emitter
    │   │   ├── gsap/                       # GSAP useGSAP() hook emitter
    │   │   ├── framer/                     # Framer Motion motion.div emitter
    │   │   └── svg/                        # SVG vector & morph emitter
    │   └── bundler/                        # Standalone ZIP package generator
    │
    └── app/                                # NEXT.JS APP ROUTER
        ├── layout.tsx                      # Root layout with font imports
        ├── page.tsx                        # Screen 00: Interactive Project Hub
        └── editor/                         # Screen 01–12: Design Studio IDE
            └── page.tsx                    # Loads EditorShell with active project
```

---

## 3. Hierarchy B: The User Project & Asset Data Hierarchy

When a user saves or exports their work, it is represented as a clean, portable declarative structure:

```text
MyAnimatedButton.motionproj/
│
├── project.json                            # Project manifest & metadata
│                                           # (Scope: Element, Framework: Next.js, Styling: Tailwind)
│
├── elements/                               # UI Element AST Definitions
│   └── root.element.json                   # Root container, child nodes, properties
│
├── animations/                             # Choreographed Animation Timelines
│   ├── hover.timeline.json                 # Hover state timeline tracks & keyframes
│   ├── tap.timeline.json                   # Tap spring parameters & duration
│   └── scroll.timeline.json                # ScrollTrigger thresholds & markers
│
├── curves/                                 # Custom Easing Curves
│   └── custom-bounce.curve.json            # Cubic bezier tangent points
│
└── exported/                               # Generated Production Code (Ready to copy)
    ├── MagneticButton.tsx                  # Standalone Next.js/React component
    ├── useButtonMotion.ts                  # Clean GSAP / Framer Motion hook
    └── README.md                           # Copy-paste & install instructions
```

---

## 4. In-Memory AST Hierarchy

The reactive state store (`useProjectStore.ts`) manages the project as a structured in-memory AST:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          MotionProjectAST (Root)                            │
│  - id: string                                                               │
│  - name: string                                                             │
│  - scope: 'element' | 'component' | 'page'                                  │
│  - target: { framework: 'nextjs'|'react'|'vue', styling: 'tailwind'|'css' } │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
                    ┌──────────────────┴──────────────────┐
                    ▼                                     ▼
      ┌───────────────────────────┐         ┌───────────────────────────┐
      │      ElementNodeAST       │         │   AnimationTimelineAST    │
      │  - id: string             │         │  - id: string             │
      │  - archetype: ArchetypeId │         │  - trigger: TriggerConfig │
      │  - styles: StyleProps     │         │  - duration: number (sec) │
      │  - children: ElementNode[]│         │  - tracks: MotionTrack[]  │
      └─────────────┬─────────────┘         └─────────────┬─────────────┘
                    │                                     │
                    │ connects via track.elementId        │
                    └─────────────────────────────────────┘
                                                          │
                                         ┌────────────────┴────────────────┐
                                         ▼                                 ▼
                           ┌───────────────────────────┐     ┌───────────────────────────┐
                           │      MotionTrackAST       │     │       KeyframeAST         │
                           │  - property: PropertyPath │     │  - time: number (sec)     │
                           │  - engine: 'gsap'|'framer'│     │  - value: number | string │
                           │  - keyframes: Keyframe[]  │     │  - easing: BezierEasing   │
                           └───────────────────────────┘     └───────────────────────────┘
```

---

## 5. Execution Lifecycle: From Visual Edit to Code Export

```
┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
│ 1. VISUAL EDIT  │ ────> │ 2. AST MUTATION │ ────> │ 3. LIVE SANDBOX │
│ User drags a    │       │ Zustand store   │       │ GSAP/Framer     │
│ keyframe diamond│       │ updates with    │       │ runtime scrubs  │
│ or slider       │       │ undo/redo stack │       │ preview at 60fps│
└─────────────────┘       └─────────────────┘       └─────────────────┘
                                                              │
                                                              ▼
┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
│ 6. DROP INTO    │ <──── │ 5. 1-CLICK COPY │ <──── │ 4. CODE EMITTER │
│ EXTERNAL REPO   │       │ Formatted TSX   │       │ Babel AST builds│
│ Runs identically│       │ copied directly │       │ clean, idiomatic│
│ with zero setup │       │ to clipboard    │       │ production code │
└─────────────────┘       └─────────────────┘       └─────────────────┘
```
