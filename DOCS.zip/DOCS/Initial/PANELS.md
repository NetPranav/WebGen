# COMPLETE PANEL & TAB REGISTRY — INITIAL PHASE

## Project Name: Visual Motion & Frontend Design Studio
**Internal Codename:** "Unreal Engine for Animation & Frontend Design"  
**Document Version:** 1.0.0  
**Phase:** Initial Phase (Design, Motion & Code Emitter)  
**Status:** Production-Ready Specification  
**File Location:** `DOCS/Initial/PANELS.md`  

---

## 1. Overview

This document is the **single source of truth** for every dockable panel, floating window, and tabbed view in the Initial Phase of the Visual Motion & Frontend Design Studio.

Every panel listed here can be:
- **Docked** to the left, right, bottom, or center dock zones
- **Stacked** as tabs within the same dock zone
- **Floated** as an independent window with soft elevation shadows (`border-radius: 16px`)
- **Collapsed** to a slim icon-only side strip (36px width)
- **Resized** via fluid 2D and 1D splitter drag handles
- **Opened / Closed** via the `Window` menu or keyboard shortcuts

The Initial Phase provides **12 core dockable panels** plus **1 standalone launcher page** (The Project Hub). All database, SQL/Prisma, API endpoints, Auth RBAC, and cloud deployment panels from the full-stack engine have been completely eliminated.

---

## 1.1 The Inside-Out Architecture Law: How Panels Connect to Elements

Every panel operates under the **Inside-Out Engine Law**:
UI surfaces (inspectors, viewports, timelines, curve editors) NEVER manipulate raw CSS or DOM state directly. Instead, all functionality is structured in 4 concentric tiers from the innermost core outward to the UI:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TIER 1: INNERMOST PROPERTY & MOTION CONTRACTS (`src/core/motion/types/`)     │
│ Declarative schemas: Track types, CSS properties, keyframe values, units.   │
├─────────────────────────────────────────────────────────────────────────────┤
│ TIER 2: ENGINE ANIMATION & STYLE EVALUATOR (`src/core/motion/engine/`)      │
│ Validates legality: Can archetype X accept property track Y or ease Z?      │
├─────────────────────────────────────────────────────────────────────────────┤
│ TIER 3: DIAGNOSTIC BUS & OUTPUT LOG (`Panel 08: Output Log & Diagnostics`)  │
│ Traps invalid connections, emitting structured `[ANIM_COMPAT]` diagnostics. │
├─────────────────────────────────────────────────────────────────────────────┤
│ TIER 4: UI PRESENTATION & VISUAL REFLECTION (`src/editor/panels/`)           │
│ Visual panels display and edit ONLY validated innermost properties.         │
└─────────────────────────────────────────────────────────────────────────────┘
```

When an animation track, easing curve, or styling rule is attached to an element:
1. It queries the **Innermost Property & Motion Contract** (`src/core/motion/types/`).
2. The **Engine Animation Evaluator** verifies that the target element archetype supports that property track (e.g. SVG path morph tracks can only attach to SVG path elements).
3. If incompatible, a diagnostic event `[ANIM_COMPAT]` is dispatched to the Output Log with exact remediation advice, and the UI displays an inline warning badge without crashing.
4. If compatible, the AST transaction commits and updates the visual Sequencer and Viewport smoothly.

---

## 2. Panel Registry Summary (Initial Phase)

| # | Panel Name | Category | Unreal Equivalent | Shortcut | Priority |
|---|-----------|----------|-------------------|----------|----------|
| 00 | Project Hub & Design Launcher | Launcher | Epic Games Launcher | — | MVP |
| 01 | Application Viewport | Core Studio | Level Viewport | — | MVP |
| 02 | Element & Animation Outliner | Core Studio | World Outliner (Streamlined) | `Ctrl+Shift+O` | MVP |
| 03 | Properties & Details Inspector | Core Studio | Details Panel | `Ctrl+Shift+D` | MVP |
| 04 | Content & Motion Browser | Core Studio | Content Browser | `Ctrl+Shift+B` | MVP |
| 05 | Motion Sequencer & Timeline | Motion & Animation | Sequencer | `Ctrl+Shift+M` | MVP |
| 06 | Cubic Bezier & Spring Curve Editor | Motion & Animation | Curve Editor | `Ctrl+Shift+K` | MVP |
| 07 | Live Code Inspector & Clean Exporter | Code Generation | — (VS Code-inspired) | `Ctrl+Shift+G` | MVP |
| 08 | Output Log & Motion Diagnostics | Debug & Diagnostics | Output Log | `Ctrl+Shift+C` | MVP |
| 09 | Play & Interaction Sandbox | Simulation | Play in Editor (PIE) | `Ctrl+Enter` | MVP |
| 10 | Whiteboard Canvas & Moodboard | Visual Planning | — (Confluence-inspired) | — | Phase 2 |
| 11 | MotionAI Co-Pilot Assistant | AI & Intelligence | — (Our innovation) | `Ctrl+Shift+I` | Phase 2 |
| 12 | Design Tokens & Preset Manager | Design System | Material Instance Editor | — | Phase 2 |

---

## 3. Detailed Panel Specifications

---

### Panel 00: Project Hub & Design Launcher
* **Role:** Primary project setup page presented on app launch (`/`).
* **Category:** Launcher (Standalone Full-Screen View)
* **Unreal Equivalent:** Epic Games Launcher / Unreal Project Browser
* **Features:**
  * **Design Scope Selector (Left Side):**
    - **Element Design:** Focused on micro-interactions, buttons, switches, icons, and SVG morphs.
    - **Component Design:** Focused on compound widgets like navbars, pricing cards, carousels, and modals.
    - **Page / Section Design:** Focused on hero layouts, feature showcases, and narrative smooth-scroll stages.
  * **Tech Stack Configurator (Right Side):**
    - Framework dropdown: Next.js 15 (App/Pages), React 19 (Vite), Vue 3, Svelte 5, Vanilla HTML/JS.
    - Styling dropdown: Tailwind CSS (v4/v3), Vanilla CSS, CSS Modules, Styled Components.
    - Animation dropdown: GSAP 3.12, Framer Motion 11, SVG & Native CSS, Hybrid.
    - TypeScript vs JavaScript toggle.
    - Primary "Launch Studio" button leading to the tailored IDE.

---

### Panel 01: Application Viewport
* **Role:** Interactive canvas where UI elements are styled, arranged, and animated.
* **Category:** Core Studio
* **Unreal Equivalent:** Level Viewport
* **Default Dock Position:** Center Canvas
* **Features:**
  * **Scope-Aware Framing:**
    - Isolated bounding box for Element mode with state tabs (Default, Hover, Active, Focus).
    - Responsive frame with handles for Component mode.
    - Full responsive stage for Page mode with Desktop (1440px), Tablet (768px), and Mobile (375px) presets.
  * **On-Canvas Interaction Handles:** Direct manipulation of scale, rotation pivot, margin, and padding.
  * **Live Scrub Overlay:** ScrollTrigger scrub simulator bar allowing live scrubbing of scroll-linked animations.
  * **Visual State Overlays:** Bounding box highlights, flexbox direction indicators, and CSS grid lines.

---

### Panel 02: Element & Animation Outliner (Simplified)
* **Role:** Hierarchical tree view representing the UI element tree and attached animation tracks.
* **Category:** Core Studio
* **Unreal Equivalent:** World Outliner (Specialized for Frontend & Motion)
* **Default Dock Position:** Left Dock (Top Half)
* **Features:**
  * **Clean Hierarchy:**
    ```text
    Button Root
    ├── SVG Icon (ArrowRight)
    │   └── 🎬 Hover Spin (+45deg, GSAP)
    ├── Text ("Subscribe")
    │   └── 🎬 Color Fade (White ➔ Emerald)
    └── 🎬 Animation Stack
        ├── ⚡ Hover Timeline (Scale 1.05, Shadow Pulse)
        ├── ⚡ Tap Spring (Framer: stiffness: 400, damping: 25)
        └── ⚡ Scroll Trigger (FadeInUp, Start: top 80%)
    ```
  * **Direct Content Browser Linkage:** Drag-and-drop animation presets from Content Browser directly onto elements.
  * **Quick Add (`+`):** One-click button to attach Hover, Tap, Scroll, Loop, or Entrance animations.
  * **Track Controls:** Eye icon (mute animation track), lock icon, solo track playback.

---

### Panel 03: Properties & Details Inspector
* **Role:** Contextual inspector for configuring styles, layout, and motion triggers.
* **Category:** Core Studio
* **Unreal Equivalent:** Details Panel
* **Default Dock Position:** Right Dock
* **Features:**
  * **Transform Section:** X, Y, Z, Width, Height, Aspect Ratio, Rotation (deg), Scale, Transform Origin.
  * **Layout Section:** Display (Flex, Grid, Block), Direction, Justify, Align, Gap, Wrap, Padding, Margin.
  * **Appearance Section:** Background (Solid, Linear/Radial Gradient, Glassmorphism blur), Border, 4-corner Radius, Box Shadows.
  * **Typography Section:** Font family, Weight, Size, Line Height, Letter Spacing, Alignment, Color.
  * **SVG Vector Section (Contextual):** Fill, Stroke, Stroke Width, Dasharray, Dashoffset, Path Data (`d`).
  * **Motion Triggers Section:** Attach triggers (`onHover`, `onClick`, `onScroll`, `onMount`) and select timelines.

---

### Panel 04: Content & Motion Browser
* **Role:** Central asset repository for animation presets, easing curves, vector shapes, and component templates.
* **Category:** Core Studio
* **Unreal Equivalent:** Content Browser
* **Default Dock Position:** Bottom Drawer (Left Tab)
* **Features:**
  * **Folder Navigation:** `Presets/Hover/`, `Presets/Entrances/`, `Presets/Scroll/`, `Curves/`, `Vectors/`, `Components/`.
  * **Live Hover Previews:** Hovering over an animation preset plays a 1.5-second preview in the card thumbnail.
  * **Drag-to-Stage & Drag-to-Outliner:** Instant binding of animation presets onto selected elements.
  * **Asset Importer:** Drag-and-drop import of custom SVG files, Lottie JSON, and Google Fonts.

---

### Panel 05: Motion Sequencer & Timeline
* **Role:** Multi-track keyframe editor for choreographing complex time-based and scroll-based animations.
* **Category:** Motion & Animation
* **Unreal Equivalent:** Sequencer
* **Default Dock Position:** Bottom Drawer (Center Tab)
* **Shortcut:** `Ctrl+Shift+M`
* **Features:**
  * **Multi-Track Timeline:** Dedicated horizontal tracks for Transform, Opacity, Color, SVG Path, and Blur.
  * **Diamond Keyframes:** Add, delete, drag, snap, and box-select multiple keyframes.
  * **ScrollTrigger Scrub Track:** Define scroll start/end trigger lines and scrub smoothing.
  * **Playback Controls:** Play, Pause, Loop, Reverse, Scrub bar, speed toggles (0.25x, 0.5x, 1x, 2x).
  * **Stagger Manager:** Configure sequential delays across multiple child elements (`start`, `center`, `random`).

---

### Panel 06: Cubic Bezier & Spring Curve Editor
* **Role:** Visual easing curve workstation powered by C++ WebAssembly for smooth interpolation.
* **Category:** Motion & Animation
* **Unreal Equivalent:** Curve Editor
* **Default Dock Position:** Bottom Drawer (Tab beside Sequencer)
* **Shortcut:** `Ctrl+Shift+K`
* **Features:**
  * **Interactive Bezier Handles:** Visual canvas with tangent handles to sculpt custom `cubic-bezier(x1, y1, x2, y2)` curves.
  * **C++ Wasm Math Kernel:** Solves cubic splines and arc-length parameterization at 120 FPS.
  * **Spring Dynamics Workspace:** Configure Framer Motion physics (`stiffness`, `damping`, `mass`) with live visual bounce graph.
  * **Preset Library:** 1-click apply for standard curves: `Power2Out`, `Power4InOut`, `ElasticOut`, `BounceOut`, `Anticipate`.

---

### Panel 07: Live Code Inspector & Clean Exporter
* **Role:** Real-time production code viewer and exporter.
* **Category:** Code Generation
* **Unreal Equivalent:** Source Code Generator
* **Default Dock Position:** Bottom Drawer or Floating Window
* **Shortcut:** `Ctrl+Shift+G`
* **Features:**
  * **Split Tabs:** `Component.tsx`, `useAnimation.ts`, `styles.css` / `tailwind.config.ts`.
  * **Zero Lock-In:** Emits clean, readable TypeScript using standard npm libraries (`gsap`, `framer-motion`, `lucide-react`).
  * **1-Click Copy:** Copies code formatted with Prettier directly to clipboard.
  * **Export ZIP Package:** Generates a ready-to-run folder with component, TypeScript types, and quickstart documentation.

---

### Panel 08: Output Log & Motion Diagnostics
* **Role:** Diagnostic event stream recording CSS evaluation, animation compatibility, and compiler warnings.
* **Category:** Debug & Diagnostics
* **Unreal Equivalent:** Output Log
* **Default Dock Position:** Bottom Drawer (Right Tab)
* **Shortcut:** `Ctrl+Shift+C`
* **Features:**
  * **Diagnostic Channels:** Filter by `All`, `[ANIM_COMPAT]`, `[CSS_ERR]`, `[SVG_WARN]`, `[EMITTER]`.
  * **One-Click Remediation:** Clicking an error jumps directly to the invalid keyframe or property input.
  * **Performance Counter:** Real-time FPS monitor, active tween count, and repaint frequency.

---

### Panel 09: Play & Interaction Sandbox
* **Role:** Interactive simulation mode allowing full user interaction with the designed element or page.
* **Category:** Simulation
* **Unreal Equivalent:** Play in Editor (PIE)
* **Default Dock Position:** Viewport Overlay
* **Shortcut:** `Ctrl+Enter`
* **Features:**
  * **Full Interaction:** Test hover, drag, tap, scroll, and focus states in an isolated sandbox.
  * **Slow-Motion Scrub:** 10% speed slider to verify micro-interactions frame-by-frame.
  * **State Toggle HUD:** Force states (e.g. permanently simulate `:hover` or `:active`).

---

### Panel 10: Whiteboard Canvas & Moodboard
* **Role:** Confluence-style infinite canvas for visual planning, inspiration moodboards, and annotations.
* **Category:** Visual Planning
* **Default Dock Position:** Floating or Center Tab
* **Features:**
  * Infinite dot-grid workspace (`#FCFDFD`).
  * Sticky notes, freehand pen markup, and inspiration image pasting.
  * Relationship arrows connecting moodboard ideas to components on stage.

---

### Panel 11: MotionAI Co-Pilot Assistant
* **Role:** Conversational AI assistant for generating, tuning, and debugging animation sequences.
* **Category:** AI & Intelligence
* **Default Dock Position:** Right Dock (Beside Details Inspector)
* **Shortcut:** `Ctrl+Shift+I`
* **Features:**
  * Natural language prompts: *"Add a subtle floating idle animation with a 3-second cycle."*
  * Visual Diff View: Translucent green ghost keyframes show proposed changes before the user commits them.
  * Diagnostic Assistant: Suggests performance optimizations for heavy SVG path morphs or layout reflows.

---

### Panel 12: Design Tokens & Preset Manager
* **Role:** Centralized repository for project colors, typography, border radii, and easing tokens.
* **Category:** Design System
* **Unreal Equivalent:** Material Instance Editor
* **Default Dock Position:** Left Dock (Tab beside Outliner)
* **Features:**
  * Manage global CSS variables and Tailwind theme extensions.
  * Define shared animation tokens (`--duration-quick: 200ms`, `--ease-bounce: cubic-bezier(...)`).
  * Token changes update all elements and animations instantly without page reloads.

---

## 4. Workspace Layout Presets

| Workspace Preset | Primary Panels | Ideal For |
| :--- | :--- | :--- |
| **Motion Choreography (Default)** | Viewport + Outliner + Details + Sequencer + Curve Editor | Time-based and scroll-based animation work |
| **Frontend Styling** | Viewport + Outliner + Details Panel + Design Tokens | Layout (Flex/Grid), typography, and CSS styling |
| **SVG & Vector Workshop** | Viewport + Outliner + SVG Details + Curve Editor | Vector path morphing and stroke drawing |
| **Code Export & Review** | Viewport + Live Code Inspector + Output Log | Inspecting generated TypeScript/Tailwind and copying code |
| **Clean Presentation** | Fullscreen Viewport + Floating Play Controls | Client demonstrations, screen recordings, and user testing |
