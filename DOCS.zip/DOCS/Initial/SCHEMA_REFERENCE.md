# JSON SCHEMA REFERENCE CONTRACTS — INITIAL PHASE

## Project Name: Visual Motion & Frontend Design Studio
**Internal Codename:** "Unreal Engine for Animation & Frontend Design"  
**Document Version:** 1.0.0  
**Phase:** Initial Phase (Design, Motion & Code Emitter)  
**Status:** Production-Ready Specification  
**File Location:** `DOCS/Initial/SCHEMA_REFERENCE.md`  

---

## 1. Overview

This document specifies the declarative JSON schema contracts that govern all serialized data in the Visual Motion & Frontend Design Studio.

Every schema defined here is strictly validated at runtime by Zod / TypeScript contracts before committing to the project store or code emitter.

---

## 2. Project Manifest Schema (`project.json`)

The root manifest defining the project metadata, design scope, and target tech stack.

```json
{
  "$schema": "https://motion-studio.dev/schemas/project-v1.json",
  "id": "proj_98a7df8a",
  "name": "MagneticPulseButton",
  "version": "1.0.0",
  "scope": "element",
  "target": {
    "framework": "nextjs-app",
    "styling": "tailwind",
    "animation": "gsap",
    "language": "typescript"
  },
  "rootElementId": "elem_root_01",
  "timelines": [
    "tl_hover_01",
    "tl_tap_01",
    "tl_inview_01"
  ],
  "createdAt": "2026-09-17T12:00:00Z",
  "updatedAt": "2026-09-17T12:15:00Z"
}
```

### Supported Values
* `scope`: `"element"` | `"component"` | `"page"`
* `target.framework`: `"nextjs-app"` | `"nextjs-pages"` | `"react-vite"` | `"vue"` | `"svelte"` | `"vanilla"`
* `target.styling`: `"tailwind"` | `"vanilla-css"` | `"css-modules"` | `"styled-components"`
* `target.animation`: `"gsap"` | `"framer-motion"` | `"svg-native"` | `"hybrid"`
* `target.language`: `"typescript"` | `"javascript"`

---

## 3. Element AST Schema (`element.json`)

Defines a visual UI node, its layout properties, styling tokens, and child relationships.

```json
{
  "id": "elem_btn_01",
  "name": "Primary Action Button",
  "archetype": "button",
  "tag": "button",
  "layout": {
    "display": "flex",
    "direction": "row",
    "justify": "center",
    "align": "center",
    "gap": "8px",
    "padding": { "top": "12px", "right": "24px", "bottom": "12px", "left": "24px" },
    "margin": { "top": "0px", "right": "0px", "bottom": "0px", "left": "0px" }
  },
  "transform": {
    "x": 0,
    "y": 0,
    "z": 0,
    "scale": 1.0,
    "rotate": 0,
    "origin": { "x": "50%", "y": "50%" }
  },
  "appearance": {
    "background": {
      "type": "solid",
      "color": "#206859"
    },
    "border": {
      "width": "1px",
      "style": "solid",
      "color": "rgba(255, 255, 255, 0.2)"
    },
    "radius": {
      "topLeft": "12px",
      "topRight": "12px",
      "bottomRight": "12px",
      "bottomLeft": "12px"
    },
    "shadows": [
      {
        "x": 0,
        "y": 8,
        "blur": 24,
        "spread": -4,
        "color": "rgba(32, 104, 89, 0.35)"
      }
    ]
  },
  "children": [
    {
      "id": "elem_icon_01",
      "name": "Sparkle Icon",
      "archetype": "svg_icon",
      "tag": "svg",
      "svg": {
        "viewBox": "0 0 24 24",
        "strokeWidth": 2,
        "stroke": "#FFFFFF",
        "fill": "none",
        "path": "M12 2L15 9L22 12L15 15L12 22L9 15L2 12L9 9Z"
      }
    },
    {
      "id": "elem_text_01",
      "name": "Button Label",
      "archetype": "text",
      "tag": "span",
      "typography": {
        "fontFamily": "Inter, sans-serif",
        "fontSize": "15px",
        "fontWeight": 600,
        "lineHeight": "20px",
        "color": "#FFFFFF"
      },
      "content": "Get Started Free"
    }
  ]
}
```

---

## 4. Animation Timeline Schema (`timeline.json`)

Defines a multi-track motion sequence with triggers, playback behavior, and keyframes.

```json
{
  "id": "tl_hover_01",
  "name": "Card Hover Lift & Glow",
  "trigger": {
    "type": "hover",
    "targetElementId": "elem_btn_01",
    "reverseOnLeave": true
  },
  "duration": 0.4,
  "iterationCount": 1,
  "tracks": [
    {
      "id": "trk_btn_scale",
      "elementId": "elem_btn_01",
      "property": "transform.scale",
      "engine": "gsap",
      "keyframes": [
        {
          "time": 0.0,
          "value": 1.0,
          "easing": "linear"
        },
        {
          "time": 0.4,
          "value": 1.05,
          "easing": {
            "type": "cubic-bezier",
            "points": [0.25, 1, 0.5, 1]
          }
        }
      ]
    },
    {
      "id": "trk_btn_y",
      "elementId": "elem_btn_01",
      "property": "transform.y",
      "engine": "gsap",
      "keyframes": [
        { "time": 0.0, "value": 0, "easing": "linear" },
        { "time": 0.4, "value": -4, "easing": "power2.out" }
      ]
    },
    {
      "id": "trk_icon_rotate",
      "elementId": "elem_icon_01",
      "property": "transform.rotate",
      "engine": "gsap",
      "keyframes": [
        { "time": 0.0, "value": 0, "easing": "linear" },
        { "time": 0.4, "value": 45, "easing": "back.out(1.7)" }
      ]
    }
  ]
}
```

---

## 5. ScrollTrigger Configuration Schema (`scrolltrigger.json`)

Defines viewport scroll boundaries and scrubbing behavior.

```json
{
  "id": "st_section_entrance",
  "triggerElementId": "elem_section_hero",
  "start": "top 80%",
  "end": "bottom 20%",
  "scrub": 0.8,
  "pin": false,
  "markers": false,
  "stagger": {
    "amount": 0.3,
    "from": "start",
    "ease": "power1.inOut"
  }
}
```

---

## 6. Framer Motion Spring Physics Schema (`spring.json`)

Defines physical spring parameters for Framer Motion transitions.

```json
{
  "type": "spring",
  "stiffness": 400,
  "damping": 25,
  "mass": 0.8,
  "restDelta": 0.001,
  "restSpeed": 0.001
}
```

---

## 7. SVG Path Morph Schema (`svg-morph.json`)

Defines vector path morphing between two matching SVG path strings.

```json
{
  "id": "svg_morph_play_pause",
  "elementId": "elem_icon_play",
  "property": "svg.path",
  "startPath": "M8 5v14l11-7z",
  "endPath": "M6 19h4V5H6v14zm8-14v14h4V5h-4z",
  "duration": 0.3,
  "easing": "power2.inOut"
}
```

---

## 8. Export Configuration & Manifest Schema (`export-manifest.json`)

Defines how the project is compiled into production files for external integration.

```json
{
  "componentName": "MagneticButton",
  "outputDirectory": "./exported",
  "files": [
    {
      "filename": "MagneticButton.tsx",
      "role": "component",
      "language": "typescript"
    },
    {
      "filename": "useMagneticMotion.ts",
      "role": "animation-hook",
      "language": "typescript"
    },
    {
      "filename": "README.md",
      "role": "instructions",
      "language": "markdown"
    }
  ],
  "npmDependencies": {
    "gsap": "^3.12.5",
    "lucide-react": "^0.450.0"
  }
}
```
