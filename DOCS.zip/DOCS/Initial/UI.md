# UI & WORKSPACE ARCHITECTURE SPECIFICATION — INITIAL PHASE

## Project Name: Visual Motion & Frontend Design Studio
**Internal Codename:** "Unreal Engine for Animation & Frontend Design"  
**AI Assistant Codename:** MotionAI  
**Document Version:** 1.0.0  
**Phase:** Initial Phase (Design, Motion & Code Emitter)  
**Status:** Approved for Design & Interface Engineering  
**File Location:** `DOCS/Initial/UI.md`  

---

## 1. Executive Design Philosophy: "Confluence Canvas + Refined Unreal Shell"

The user interface of the Visual Motion & Frontend Design Studio synthesizes two paradigms:
1. **The Luminous, Infinite Whiteboard of Atlassian Confluence:** Clean, open, distraction-free creative workspace with an infinite dot-grid canvas (`#FCFDFD`), crisp typography, and floating frosted-glass tool docks.
2. **The Ergonomic Power of Unreal Engine:** Professional IDE panels, dockable window management, contextual inspectors, multi-track animation timelines, and high-frequency curve editing.

Instead of the dark, dense, 1990s CAD-like aesthetic typical of 3D software, the studio uses a **modern, refined light aesthetic** featuring soft rounded curves (`border-radius: 16px`), generous padding, subtle elevation shadows, and clean typography.

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ ⚡ MotionStudio  •  Saved just now  [Element: MagneticButton]  [▶ Play Mode]  [Export Code]  [MotionAI]  │
├──────────────────────────┬──────────────────────────────────────────────────────────────┬───────────────┤
│ ELEMENT & ANIMATION      │                      STAGE VIEWPORT                          │ DETAILS PANEL │
│ OUTLINER                 │                                                              │ (Right Panel) │
│ (Simplified Left Panel)  │  ┌────────────────────────────────────────────────────────┐  │               │
│                          │  │  STAGE CANVAS (Centered Frame)                         │  │ ▾ Transform   │
│ ▾ Button Root            │  │                                                        │  │   X: 0px      │
│   ├── Icon (ArrowSVG)    │  │       ┌────────────────────────┐                       │  │   Y: 0px      │
│   │   └── 🎬 Rotate+45°  │  │       │  [✦ Get Started →]     │ ◄── (Selected)        │  │   W: Auto     │
│   ├── Label ("Started")  │  │       └────────────────────────┘                       │  │   H: 48px     │
│   │   └── 🎬 ColorFade   │  │                                                        │  │               │
│   └── 🎬 Animation Stack │  └────────────────────────────────────────────────────────┘  │ ▾ Layout      │
│       ├── ⚡ Hover State │                                                              │   Display:Flex│
│       ├── ⚡ Tap Spring  │  [ Undo / Redo ]                      [ Zoom: - 100% + ]     │   Gap: 8px    │
│       └── ⚡ InView Fade │                                                              │               │
│                          │     ┌──────────────────────────────────────────────────┐     │ ▾ Styling     │
│ ▾ CONTENT BROWSER        │     │ FLOATING DOCK: Select | Pan | Text | Shape |     │     │   Bg: #206859 │
│   📁 Animation Presets   │     │ SVG Path | Motion Preset | Code | +              │     │   Radius: 10px│
│   📁 Easing Curves       │     └──────────────────────────────────────────────────┘     │ ▾ Triggers    │
│   📁 SVG Vector Shapes   │                                                              │   onHover:... │
├──────────────────────────┴──────────────────────────────────────────────────────────────┴───────────────┤
│ EXPANDABLE BOTTOM DRAWER:  [Motion Sequencer]  [Curve Editor]  [Code Inspector]  [Console]  [MotionAI]   │
└─────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Visual Theme, Tokens & Styling Guidelines

### 2.1 Color Palette
* **Canvas Background:** `#FCFDFD` (Luminous Warm White)
* **Dot Grid Matrix:** `#E2E8F0` (Subtle Slate Dots, 24px spacing)
* **Panel Background:** `#FFFFFF` with `backdrop-filter: blur(20px)` and `rgba(255, 255, 255, 0.94)`
* **Active Surface / Hover:** `#F8FAFC` to `#F1F5F9` (Soft Slate)
* **Border Strokes:** `rgba(15, 23, 42, 0.08)` (Ultra-refined 1px micro-border)
* **Deep Text:** `#0F172A` (Slate 900)
* **Muted Text / Metadata:** `#64748B` (Slate 500)
* **Accent Primary:** `#206859` (Deep Pine Green - Brand & Active States)
* **Accent Success:** `#10B981` (Emerald - Live Playback & Active Loops)
* **Accent Warning:** `#F59E0B` (Amber - Dirty State & Animation Warnings)
* **Accent Error:** `#EF4444` (Rose - Curve & CSS Validation Errors)

### 2.2 Animation Track & Timeline Color Taxonomy
To ensure instant readability on the Sequencer timeline:

| Track Type | Hex Color | Visual Indicator | Meaning |
| :--- | :--- | :--- | :--- |
| **Position / Transform (X, Y, Z)** | `#06B6D4` | Cyan Dot / Bar | Translation, offsets, coordinates |
| **Scale & Dimension** | `#3B82F6` | Electric Blue | ScaleX, ScaleY, Width, Height |
| **Rotation & 3D Tilt** | `#8B5CF6` | Vibrant Violet | Rotation (deg), skew, perspective |
| **Opacity & Visibility** | `#E11D48` | Rose Magenta | Opacity (0–1), display, visibility |
| **Color & Background** | `#10B981` | Emerald Green | Background, text color, border color |
| **SVG Path Morph & Stroke** | `#F59E0B` | Amber Orange | `d` attribute tween, stroke-dashoffset |
| **Filter & Blur** | `#EC4899` | Pink Fuchsia | Gaussian blur, brightness, contrast |
| **Spring Physics** | `#14B8A6` | Mint Teal | Framer Motion stiffness/damping |
| **ScrollTrigger Region** | `#6366F1` | Indigo Blue | Scroll start/end markers & scrub |

### 2.3 Curvature, Elevation & Glassmorphism
* **Corner Radius:**
  * Floating Docks & Modals: `border-radius: 20px`
  * Panels & Windows: `border-radius: 16px`
  * Cards & Inspector Sections: `border-radius: 12px`
  * Buttons & Inputs: `border-radius: 8px`
* **Elevation & Shadows:**
  * Floating Docks: `box-shadow: 0 12px 36px -4px rgba(15, 23, 42, 0.08), 0 4px 12px -2px rgba(15, 23, 42, 0.04)`
  * Docked Panel Dividers: `box-shadow: 0 0 0 1px rgba(15, 23, 42, 0.06)`
* **Typography:**
  * System Font Stack: `Inter`, `Geist Sans`, or `-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto`
  * Code & Monospace: `JetBrains Mono`, `Fira Code`, or `ui-monospace`

---

## 3. Technology Stack for the Initial Phase

| Layer | Technology | Purpose |
| :--- | :--- | :--- |
| **Core Framework** | **Next.js 15 / React 19** | High-performance component architecture, SSR/SSG, fast client reconciliation. |
| **High-Performance Math** | **C++ compiled to WebAssembly (Wasm)** | 120 FPS Hermite/Cubic Bezier curve solving, cable tension, and spring dynamics. |
| **Animation Engines** | **GSAP 3.12 + Framer Motion 11** | Timeline sequencing, SVG path morphing, ScrollTrigger, and physical springs. |
| **Graphics & Rendering** | **HTML5 Canvas + SVG** | Canvas for bezier curve rendering; SVG for path manipulation and crisp vector exports. |
| **Styling Architecture** | **Vanilla CSS + Modern CSS Variables** | Bespoke design system avoiding utility lock-in with fluid curves and zero conflicts. |
| **Code Generation** | **Babel AST + Prettier Generator** | Deterministic compilation of visual AST into clean, human-readable React/Next.js/Tailwind code. |
| **State Management** | **Zustand + Immer** | Zero-latency reactive state store driving timeline scrubbing and undo/redo stacks. |

---

## 4. Comprehensive Screen Directory (Initial Phase)

The Initial Phase provides **10 dedicated screens/workspaces**, completely stripped of database, backend, and cloud overhead:

---

### Screen 00: Interactive Project Hub & Design Launcher
* **Description:** The entry point where users define their design scope and configure their target export technology.
* **Layout Structure:**
  * **Left Half: Design Scope Selection Cards:**
    1. **Element Design Card:**
       - Tagline: *"Atomic micro-interactions, buttons, switches, icons & SVG morphs."*
       - Visual badge: `Atomic Unit`
       - Recommended for: Standalone widgets to drop into existing pages.
    2. **Component Design Card:**
       - Tagline: *"Navbars, pricing cards, carousels, modals & compound interactive units."*
       - Visual badge: `Compound Component`
       - Recommended for: Reusable React/Next.js component folders.
    3. **Page / Section Design Card:**
       - Tagline: *"Hero presentations, feature grids & narrative smooth-scroll stages."*
       - Visual badge: `Full Section / Page`
       - Recommended for: Landing page sections and scroll-driven presentations.
  * **Right Half: Technology & Engine Configuration:**
    - **Target Framework Dropdown:**
      - Next.js 15 (App Router - TypeScript)
      - Next.js 15 (Pages Router - TypeScript)
      - React 19 (Vite - TypeScript)
      - Vue 3 (Composition API)
      - Svelte 5 (Runes)
      - Vanilla HTML5 / ES6 JavaScript
    - **Styling System Dropdown:**
      - Tailwind CSS (v4 / v3 Utility Classes)
      - Vanilla CSS / Modern CSS Variables
      - CSS Modules (`*.module.css`)
      - Styled Components / Emotion
    - **Animation Engine Dropdown:**
      - GSAP 3.12 (GreenSock Timeline & ScrollTrigger)
      - Framer Motion 11 (Springs, Gestures & AnimatePresence)
      - SVG Vector & Native CSS (Path morphing, keyframes, zero bundle size)
      - Combined Hybrid (GSAP for scroll, Framer for spring micro-interactions)
    - **Language Toggle:** `[•] TypeScript` / `[ ] JavaScript`
    - **Primary CTA Button:** `🚀 Launch Design Studio →`

---

### Screen 01: Application Viewport
* **Description:** The central visual stage where developers design, arrange, and animate UI elements.
* **Core Capabilities:**
  * **Scope-Aware Framing:**
    - In **Element Mode:** Canvas focuses on a flexible centered bounding stage with contrast toggles (Dark, Light, Transparent checkerboard) and state simulator tabs (Default, Hover, Active, Focus).
    - In **Component Mode:** Responsive container with fluid resize handles and component variant toggles.
    - In **Page Mode:** Full responsive stage with Desktop (1440px), Tablet (768px), and Mobile (375px) presets.
  * **On-Canvas Visual Handles:** Direct dragging of padding, margin, rotation angle, scale handles, and transform origin dot.
  * **Inline Text Editing:** Double-click any label to modify text with real-time typography preview.
  * **ScrollTrigger Scrub Simulator:** In Page Mode, a virtual scrollbar overlays the viewport, letting the user scrub scroll position to preview ScrollTrigger animations in real time.

---

### Screen 02: Simplified Element & Animation Outliner
* **Description:** The streamlined left-side hierarchy focused strictly on UI elements and their attached animations.
* **Core Capabilities:**
  * **Hierarchy Model:**
    ```text
    Button (Root Container)
    ├── Icon (SVG Path: LucideSparkles)
    │   └── 🎬 Spin Entrance (GSAP, 0.4s, Back.out)
    ├── Text Label ("Generate")
    │   └── 🎬 Shimmer Gradient (CSS Keyframes, Infinite)
    └── 🎬 Attached Animation Stacks
        ├── ⚡ Hover Timeline (GSAP: Scale 1.04, Glow Shadow)
        ├── ⚡ Active Tap (Framer: Scale 0.96, Stiffness 400)
        └── ⚡ In-View Entrance (ScrollTrigger: FadeIn + Stagger)
    ```
  * **Quick Animation Add (`+`):** Clicking `+` next to any node opens a popup of animation types (Hover, Tap, Scroll, Entrance, Exit, Loop).
  * **Direct Content Browser Link:** Dragging an animation preset from the Content Browser directly onto an Outliner item binds it instantly.
  * **Visibility & Solo Toggles:** Mute or solo individual animation tracks to isolate specific motion choreographies.

---

### Screen 03: Properties & Details Inspector
* **Description:** Context-aware inspector adapting to the selected element or animation keyframe.
* **Core Sections:**
  * **Transform:** X, Y, Z coordinates, Width, Height, Z-Index, Aspect Ratio, Rotation (deg), Scale.
  * **Layout (Flex / Grid):** Direction, Justify, Align, Gap, Wrap, Padding, Margin.
  * **Appearance:** Solid Color, Linear/Radial Gradients, Glassmorphism blur, Border, 4-corner independent Radius, Box Shadow.
  * **Typography:** Font family, Weight slider, Size, Line height, Letter spacing, Alignment.
  * **SVG Vector Properties (when SVG selected):** Fill, Stroke, Stroke Width, Stroke Dasharray, Stroke Dashoffset, Path Data (`d`).
  * **Motion Trigger Inspector:** Assign triggers (`onHover`, `onClick`, `onScrollIntoView`, `onMount`) and select the target timeline.

---

### Screen 04: Content & Motion Browser
* **Description:** Asset management panel containing reusable design building blocks and animation presets.
* **Core Directories:**
  * `Presets/Hover/` — Magnetic pulls, scale bounces, neon glows, border shines.
  * `Presets/Entrances/` — Fade up, staggered text reveal, elastic pop, 3D flip.
  * `Presets/Scroll/` — Parallax depth, horizontal scrub, pin container, progress fills.
  * `Curves/` — Curated bezier curves (EaseInOutCubic, Power4Out, ElasticEase, SpringSnappy).
  * `Vectors/` — Popular SVG shapes, icons, badges, dividers, and morph targets.
  * `Components/` — Pre-built animated components (Magnetic Button, Bento Grid, Floating Navbar).

---

### Screen 05: Motion Sequencer & Bezier Curve Editor
* **Description:** Unreal Sequencer-inspired multi-track timeline for precision animation choreography.
* **Core Capabilities:**
  * **Multi-Track Stacking:** Add tracks for any property (`opacity`, `transform.y`, `scale`, `filter.blur`, `svg.path`).
  * **Diamond Keyframes:** Click timeline to drop keyframes, drag to retime, select multiple to stretch/compress duration.
  * **Interactive Bezier Curve Editor:** Full curve viewport powered by C++ Wasm. Drag tangent handles to shape custom easing curves.
  * **Playback Controls:** Play (▶), Pause (⏸), Loop (🔁), Reverse (◀), Scrub speed (0.5x, 1x, 2x), Current time readout (`00:01.250`).
  * **ScrollTrigger Track:** Set start/end scroll offsets and scrub smoothness directly on the timeline.

---

### Screen 06: Play & Interaction Sandbox
* **Description:** Zero-build sandbox to test micro-interactions exactly as they will feel in production.
* **Core Capabilities:**
  * **Real User Interactions:** Hover over buttons to feel spring resistance; scroll the page to observe parallax; click toggles to test layout morphing.
  * **Interactive Debug HUD:** Displays current FPS, active tween count, running GSAP timelines, and spring velocity.
  * **Slow-Motion Inspection:** Slider to slow down playback to 10% speed for frame-by-frame micro-interaction inspection.

---

### Screen 07: Live Code Inspector & Clean Exporter
* **Description:** Split-screen code viewer displaying the generated production code in real time.
* **Core Capabilities:**
  * **Syntax Highlighted Tabs:** `Component.tsx`, `useAnimation.ts`, `styles.css` / `tailwind.config.ts`.
  * **Instant Reactive Updates:** Moving a keyframe or editing a padding slider updates the code preview with zero lag.
  * **Zero Lock-In Guarantee:** Clean, readable code using standard imports (`import gsap from "gsap"`, `import { motion } from "framer-motion"`).
  * **1-Click Copy:** Copies the full component code directly to the clipboard with import instructions.
  * **Download ZIP Package:** Exports a complete npm-ready folder with component, styles, TypeScript declarations, and a `README.md` on how to install dependencies.

---

### Screen 08: Whiteboard Canvas & Moodboard
* **Description:** Atlassian Confluence-style infinite whiteboard for visual planning and moodboarding.
* **Core Capabilities:**
  * Paste inspiration screenshots, color palettes, and motion reference links.
  * Draw freehand arrows and sticky notes connecting ideas to elements on stage.

---

### Screen 09: MotionAI Co-Pilot Assistant
* **Description:** Intelligent animation assistant that crafts and tweaks animations from natural language prompts.
* **Core Capabilities:**
  * Prompts like: *"Make this button bounce like an elastic spring when hovered"* or *"Create a staggered entrance for these 4 feature cards."*
  * Generates visual keyframes and curves directly on the Sequencer timeline for human inspection.
  * No Silent Writes: Displays a visual diff of proposed tracks before applying.

---

### Screen 10: Design System & Token Manager
* **Description:** Centralized manager for global design and animation constants.
* **Core Capabilities:**
  * **Easing Tokens:** Standardize project easings (`--ease-snappy`, `--ease-smooth`, `--ease-bounce`).
  * **Duration Tokens:** Standardize animation durations (`--duration-fast: 150ms`, `--duration-normal: 300ms`).
  * **Color & Typography Tokens:** Brand colors, border radii, and font families.

---

## 5. Docking Mechanics & Workspace Layout Presets

Users can switch between tailored panel configurations using the top menu (`Window` ➔ `Workspaces`):

1. **Motion Choreography (Default):** Viewport centered above the multi-track Sequencer and Bezier Curve Editor; Outliner on the left, Details on the right.
2. **Frontend Styling:** Maximizes the Details Inspector and Viewport for layout, flexbox, grid, and CSS styling.
3. **SVG & Vector Workshop:** Focuses on the SVG path inspector, stroke dashoffset controls, and vector point morphing.
4. **Code Export & Review:** Side-by-side Viewport and Live Code Inspector for immediate copy-paste workflow.
5. **Clean Presentation:** Collapses all sidebars and bottom drawers to provide a distraction-free stage for client reviews and screen recordings.
