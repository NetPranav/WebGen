# NAMING, CODING & FILE CONVENTIONS — INITIAL PHASE

## Project Name: Visual Motion & Frontend Design Studio
**Internal Codename:** "Unreal Engine for Animation & Frontend Design"  
**Document Version:** 1.0.0  
**Phase:** Initial Phase (Design, Motion & Code Emitter)  
**Status:** Production-Ready Specification  
**File Location:** `DOCS/Initial/CONVENTIONS.md`  

---

## 1. File & Directory Naming Conventions

| Entity | Convention | Example |
| :--- | :--- | :--- |
| **React Component Files** | `PascalCase.tsx` | `CanvasViewport.tsx`, `MotionSequencer.tsx` |
| **Hook Files** | `camelCase.ts` prefixed with `use` | `useProjectStore.ts`, `useTimelineStore.ts` |
| **Utility & Math Files** | `camelCase.ts` or `PascalCase.ts` | `CurveMath.ts`, `easingHelpers.ts` |
| **Stylesheet Files** | `kebab-case.css` | `tokens.css`, `outliner.css`, `sequencer.css` |
| **Directories** | `kebab-case` or lowercase | `src/editor/panels/sequencer/`, `src/core/motion/` |
| **JSON Schemas / Files** | `kebab-case.json` or `.ext.json` | `project.json`, `hover.timeline.json` |
| **C++ Header & Source** | `PascalCase.h` / `PascalCase.cpp` | `SplineSolver.h`, `SplineSolver.cpp` |

---

## 2. ID Generation Conventions

All entities inside the visual AST utilize standardized deterministic prefix-plus-hex identifiers:

| Entity Type | Prefix | Format | Example |
| :--- | :--- | :--- | :--- |
| **Project** | `proj_` | `proj_<8hex>` | `proj_98a7df8a` |
| **UI Element** | `elem_` | `elem_<archetype>_<8hex>` | `elem_btn_3f8a109c`, `elem_icon_a71b290d` |
| **Animation Timeline** | `tl_` | `tl_<trigger>_<8hex>` | `tl_hover_9a87cd10`, `tl_scroll_48bf9012` |
| **Motion Track** | `trk_` | `trk_<prop>_<8hex>` | `trk_scale_1209af8b`, `trk_rotate_6541bc3a` |
| **Keyframe Marker** | `kf_` | `kf_<timeMs>_<8hex>` | `kf_400_34ab7891` |
| **Easing Curve** | `crv_` | `crv_<name>_<8hex>` | `crv_bounce_8910fedc` |
| **ScrollTrigger** | `st_` | `st_<8hex>` | `st_78a65f12` |

---

## 3. Standard Animation Property Paths

To guarantee compatibility across the AST, Sequencer, and Code Emitters, all animatable properties follow strict dot-notation paths:

```text
transform.x                     # Offset X (px, rem, %)
transform.y                     # Offset Y (px, rem, %)
transform.z                     # 3D Depth translation (px)
transform.scale                 # Uniform scale (1.0 = 100%)
transform.scaleX                # Horizontal scale
transform.scaleY                # Vertical scale
transform.rotate                # 2D rotation (deg)
transform.rotateX               # 3D tilt X (deg)
transform.rotateY               # 3D tilt Y (deg)
appearance.opacity              # Alpha transparency (0.0 – 1.0)
appearance.background.color     # Hex or rgba color string
appearance.border.color         # Border stroke color
appearance.border.width         # Border thickness (px)
appearance.radius               # Corner radius (px)
svg.path                        # SVG "d" attribute path string
svg.strokeDashoffset            # Line drawing offset
filter.blur                     # Gaussian blur (px)
```

---

## 4. UI Architecture & Styling Isolation Rules

1. **The "One Element = One Styling Source" Principle:**
   Every UI element in the studio shell is styled by exactly ONE dedicated stylesheet. No conflicting global classes, no inline styles.
2. **Dynamic Values via CSS Variables:**
   Dynamic coordinates (pan offsets, timeline zoom levels, splitter widths) are passed via CSS custom properties on parent containers (e.g. `style={{ '--timeline-zoom': zoom } as React.CSSProperties}`).
3. **Mandatory File Header Comment:**
   Every UI component must begin with the standard documentation block:

```typescript
/**
 * ============================================================================
 * [COMPONENT NAME]
 * ============================================================================
 * UI Element: [Specific Element, e.g. Sequencer Keyframe Diamond]
 * Screen / Scope: [Screen Name, e.g. Screen 05: Motion Sequencer]
 * Role: [What this component does and renders]
 * Styling Source: [Path to the ONLY stylesheet controlling this component]
 * ============================================================================
 */
```

---

## 5. Professional Code Export Conventions

The Code Emitter must output clean, human-readable code adhering to these rules:

1. **Zero Proprietary Imports:**
   Exported components must NEVER import from `@/core`, `@/editor`, or any internal engine module. They must ONLY import from standard public packages:
   ```typescript
   // ALLOWED:
   import React, { useRef } from "react";
   import gsap from "gsap";
   import { useGSAP } from "@gsap/react";
   import { motion } from "framer-motion";
   import { ArrowRight } from "lucide-react";
   ```
2. **Explicit Props & TypeScript Interfaces:**
   Every exported component must export its own typed interface (e.g. `export interface MagneticButtonProps`).
3. **Prettier Compliance:**
   All emitted code must pass standard Prettier formatting (2-space indent, semicolons, double quotes) without syntax warnings.
