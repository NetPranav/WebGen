# IMPLEMENTATION ROADMAP & MILESTONES — INITIAL PHASE

## Project Name: Visual Motion & Frontend Design Studio
**Internal Codename:** "Unreal Engine for Animation & Frontend Design"  
**Document Version:** 1.0.0  
**Phase:** Initial Phase (Design, Motion & Code Emitter)  
**Status:** Active Execution  
**File Location:** `DOCS/Initial/ROADMAP.md`  

---

## 1. Phased Delivery Strategy

The Initial Phase is organized into **8 sequential phases**, each containing numbered sub-phases with verifiable deliverables. The objective of this roadmap is to deliver a rock-solid, production-grade visual tool for frontend design and animation that emits clean, drop-in code for any existing React, Next.js, Vue, or Vanilla project.

---

## 2. Phase Overview Summary

| # | Name | Sub-Phases | Key Deliverable | Status |
|---|---|---|---|---|
| 1 | IDE Shell, Docking & Design Tokens | 1.1–1.5 | Dockable shell, Confluence dot grid, token system | ✅ COMPLETE |
| 2 | Interactive Project Hub & Design Launcher | 2.1–2.3 | Scope cards (Element/Component/Page) + Tech stack picker | 🚀 NEXT |
| 3 | Simplified Element & Animation Outliner | 3.1–3.3 | Streamlined tree (Element ➔ Child ➔ Animation) + Content Browser | 📋 PLANNED |
| 4 | Motion Sequencer & Bezier Curve Editor | 4.1–4.4 | Multi-track keyframes, C++ Wasm Bezier solver, ScrollTrigger | 📋 PLANNED |
| 5 | Multi-Engine Animation Runtime | 5.1–5.4 | GSAP 3.12, Framer Motion 11, SVG path morph & stroke | 📋 PLANNED |
| 6 | Professional Clean Code Emitter & Exporter | 6.1–6.4 | Live code preview, 1-click copy, ZIP exporter for any repo | 📋 PLANNED |
| 7 | MotionAI Co-Pilot & Preset Ecosystem | 7.1–7.3 | Prompt-to-motion generator, visual diff, preset browser | 📋 PLANNED |
| 8 | End-to-End Verification & Integration Gate | 8.1–8.3 | Real-world drop-in testing in external Next.js/React repos | 📋 PLANNED |

---

## 3. Phase Specifications

---

### Phase 1: IDE Shell, Docking & Design Tokens — ✅ COMPLETE
**Goal:** Establish the rock-solid visual foundation, token architecture, and dockable windowing shell.

- [x] Sub-Phase 1.1: Confluence warm-white dot grid canvas (`#FCFDFD`, 24px spacing) and single-source CSS tokens (`tokens.css`).
- [x] Sub-Phase 1.2: Dockable layout infrastructure with top, bottom, left, right dock zones and resizable splitters.
- [x] Sub-Phase 1.3: 2D corner drag handles (`DockCornerSplitter.tsx`) for simultaneous width and height resizing.
- [x] Sub-Phase 1.4: Floating viewport history actions (Undo/Redo) with glassmorphic hover pills.
- [x] Sub-Phase 1.5: Design token showcase and verification page (`/`).

---

### Phase 2: Interactive Project Hub & Design Launcher — 🚀 NEXT
**Goal:** Build the dedicated launcher page (`Screen 00`) that differentiates design scope and configures target technologies before entering the editor.

- [ ] **Sub-Phase 2.1: Design Scope Selection Cards (Left Side):**
  - Implement three interactive selection cards:
    1. `Element Design`: Micro-interactions, buttons, switches, icons, and SVG morphs.
    2. `Component Design`: Compound UI widgets (navbars, pricing cards, carousels, modals).
    3. `Page / Section Design`: Full landing page sections, hero presentation stages, and smooth-scroll flows.
  - Interactive hover elevation, active border glow (`#206859`), and descriptive scope badges.
- [ ] **Sub-Phase 2.2: Technology & Engine Configurator (Right Side):**
  - Dropdown 1: **Target Framework** (Next.js 15 App Router, Next.js Pages, React 19 Vite, Vue 3, Svelte 5, Vanilla HTML/JS).
  - Dropdown 2: **Styling System** (Tailwind CSS v4/v3, Vanilla CSS, CSS Modules, Styled Components).
  - Dropdown 3: **Animation Engine** (GSAP 3.12, Framer Motion 11, SVG & Native CSS, Hybrid).
  - Toggle: **Language** (`TypeScript` default, `JavaScript`).
  - Dropdown 4: **Starting Template** (Blank Canvas, Magnetic Button, Animated Card, Hero Section).
- [ ] **Sub-Phase 2.3: Project Initialization & Workspace Tailoring:**
  - Clicking "Launch Design Studio" initializes the reactive project store with the selected configuration and navigates to the tailored studio layout.
  - Viewport framing and tool recommendations adapt automatically to the chosen scope (e.g. centered bounding frame for Element; full responsive stage for Page).
- **Verification Gate:** Selecting "Element Design" + "Next.js 15" + "Tailwind" + "GSAP" launches the studio with the element stage and initializes the project manifest.

---

### Phase 3: Simplified Element & Animation Outliner — 📋 PLANNED
**Goal:** Replace complex full-stack trees with a clean hierarchy focused strictly on UI elements, child nodes, and their attached animations.

- [ ] **Sub-Phase 3.1: Streamlined Hierarchy Tree:**
  - Build `ElementOutliner.tsx` with clean nested tree rendering:
    - Root Element / Stage Node
    - Child Nodes (Text labels, Icons, Containers, SVG Paths)
    - Attached Animation Stacks (Hover, Tap, Scroll, Entrance, Exit, Loop)
  - Inline name editing, drag-to-reorder children, and selection synchronization with the Viewport.
- [ ] **Sub-Phase 3.2: Animation Track Controls & Quick-Add Modal:**
  - Track control icons per animation: Mute (eye icon), Solo (headphone/star icon), Lock (padlock).
  - Quick-add button (`+`) opening a popover to attach new animation types to the selected element.
- [ ] **Sub-Phase 3.3: Content Browser Direct Drag-and-Drop Binding:**
  - Allow dragging animation presets from the Content Browser directly onto any item in the Outliner or canvas.
  - Dropping an asset immediately attaches the pre-configured animation tracks to that element's animation stack.
- **Verification Gate:** Dragging an "Elastic Hover" preset from the Content Browser onto an Outliner button node binds the hover animation and updates the timeline instantly.

---

### Phase 4: Motion Sequencer & Bezier Curve Editor — 📋 PLANNED
**Goal:** Provide an Unreal Sequencer-grade multi-track timeline and visual easing curve editor.

- [ ] **Sub-Phase 4.1: Multi-Track Keyframe Timeline (`MotionSequencer.tsx`):**
  - Dedicated horizontal tracks for Transform (X, Y, Z), Scale, Rotation, Opacity, Color, SVG Path, and Blur.
  - Interactive playhead with smooth scrubbing, timecode readout, and frame snapping.
  - Diamond keyframe markers: add, move, stretch, duplicate, and delete keyframes.
- [ ] **Sub-Phase 4.2: C++ WebAssembly Bezier Curve Editor (`CurveEditor.tsx`):**
  - Interactive curve visualizer with tangent handles for sculpting custom `cubic-bezier()` easing.
  - Leverage Wasm kernel (`SplineSolver.cpp`) to calculate smooth cubic spline curves and arc-length parameterization at 120 FPS.
  - Preset easing quick-picker: `Power2.out`, `Power4.inOut`, `Elastic.out`, `Bounce.out`, `Custom Bezier`.
- [ ] **Sub-Phase 4.3: ScrollTrigger Threshold Visualizer:**
  - Visual scroll trigger tracks with start/end markers, scrub toggle, and pin container options.
  - Viewport scroll simulator bar enabling real-time preview of scroll-linked animations.
- [ ] **Sub-Phase 4.4: Stagger & Delay Manager:**
  - Configure multi-element staggered entrance delays (`start`, `center`, `end`, `random`).
- **Verification Gate:** Scrubbing the Sequencer timeline smoothly animates the element on stage at 60+ FPS; modifying a bezier curve handle immediately alters easing interpolation.

---

### Phase 5: Multi-Engine Animation Runtime — 📋 PLANNED
**Goal:** Deliver visual authoring support for GSAP 3.12, Framer Motion 11, SVG vector animations, and native CSS.

- [ ] **Sub-Phase 5.1: GSAP 3.12 Core Integration:**
  - Runtime driver compiling timeline tracks to `gsap.timeline()` and `gsap.to()` calls with ScrollTrigger bindings.
- [ ] **Sub-Phase 5.2: Framer Motion 11 Core Integration:**
  - Runtime driver compiling spring physics (`stiffness`, `damping`, `mass`) and `whileHover` / `whileTap` gesture variants.
- [ ] **Sub-Phase 5.3: SVG Vector Animation Engine:**
  - Visual SVG path morphing (`d` attribute tweening with point interpolation).
  - Stroke-dashoffset animation controls for line drawing and icon flourishes.
- [ ] **Sub-Phase 5.4: Native CSS Keyframe & Spring Emitter:**
  - Pure CSS `@keyframes` generator with custom `cubic-bezier()` timing functions for zero-runtime dependencies.
- **Verification Gate:** A complex animation with both an SVG path morph and a spring bounce runs identically in both the visual preview sandbox and the compiled output.

---

### Phase 6: Professional Clean Code Emitter & Exporter — 📋 PLANNED
**Goal:** Generate human-readable, production-grade code that can be dropped directly into any external codebase with zero engine lock-in.

- [ ] **Sub-Phase 6.1: Next.js 15 & React 19 TSX Emitters:**
  - Emitter for **Tailwind CSS**: Translates visual layout, typography, and styling into clean, idiomatic Tailwind classes.
  - Emitter for **Vanilla CSS / CSS Modules**: Emits semantic JSX paired with clean, scoped `styles.module.css`.
- [ ] **Sub-Phase 6.2: Animation Code Emitter:**
  - Generates idiomatic GSAP `useGSAP()` hooks or Framer Motion `<motion.div>` components with fully typed props.
  - Zero proprietary runtime imports; uses ONLY standard npm packages (`gsap`, `framer-motion`).
- [ ] **Sub-Phase 6.3: Live Code Inspector Split-View (`CodeInspector.tsx`):**
  - Live split-view tab displaying `Component.tsx`, `useAnimation.ts`, and `styles.css`.
  - Formatted in real time using Prettier with syntax highlighting.
- [ ] **Sub-Phase 6.4: Standalone Exporter & ZIP Bundler:**
  - "1-Click Copy Code" button with copy feedback.
  - "Download ZIP Package" containing:
    - `ComponentName.tsx`
    - `styles.module.css` (if applicable)
    - `types.ts`
    - `README.md` (exact `npm install` instructions for dependencies)
- **Verification Gate:** Pasting the exported code into a freshly created `npx create-next-app` project builds without errors or warnings and reproduces the exact animations.

---

### Phase 7: MotionAI Co-Pilot & Preset Ecosystem — 📋 PLANNED
**Goal:** Provide AI-powered animation generation and an expansive library of pre-choreographed motion assets.

- [ ] **Sub-Phase 7.1: Natural Language Prompt-to-Motion:**
  - Users input prompts (e.g. *"Create a floating card with a springy magnetic pull when hovered"*).
  - MotionAI parses intent and generates keyframe tracks on the Sequencer.
- [ ] **Sub-Phase 7.2: Visual Diff & Human Approval Gate:**
  - AI-generated keyframes appear as translucent green ghost keyframes on the timeline.
  - User can scrub preview and explicitly click "Accept" or "Discard".
- [ ] **Sub-Phase 7.3: Curated Preset Library:**
  - 50+ production-grade motion presets across Hover, Entrance, Scroll, and SVG categories.
- **Verification Gate:** Asking MotionAI to "add an elastic bounce on tap" places correct spring keyframes, previews in ghost mode, and merges cleanly on approval.

---

### Phase 8: End-to-End Verification & Integration Gate — 📋 PLANNED
**Goal:** Verify complete workflow from Home Screen selection to external production deployment.

- [ ] **Sub-Phase 8.1: Full Pipeline Integration Test:**
  - Launch from Home Screen ➔ Design Element ➔ Choreograph in Sequencer ➔ Test in Sandbox ➔ Export Code.
- [ ] **Sub-Phase 8.2: Cross-Framework Export Validation:**
  - Verify exported code across:
    - Next.js 15 (App Router)
    - React 19 (Vite)
    - Vue 3
    - Vanilla HTML/JS
- [ ] **Sub-Phase 8.3: Performance & 60 FPS Guarantee:**
  - Verify animation execution maintains 60+ FPS on mid-tier hardware with zero memory leaks.
